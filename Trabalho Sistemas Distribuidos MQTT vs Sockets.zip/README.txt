Equipe: Lucas Sim�o, �caro de Lima, Mateus Cesar, Breno Negreiros.

Ao abrir ambos os projetos: Executar TelaSensores e TelaGerenciadorComp